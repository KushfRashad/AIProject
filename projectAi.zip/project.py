import numpy as np
from numpy import array,random
import pandas as pd
unit_step = lambda x: 0 if x < 1 else 1

data= pd.read_csv("ORGATE.csv")
inputs=np.array(data[['x0','x1','x2']])
inputs.tolist()
output=data['y']
output.tolist()


w = random.rand(3)
a = 0.2
n = 4
count = 0
x=3
while x!=0:
    for i in range(n):
        predicted_output=np.dot(inputs[i],w)
        print(predicted_output)
        predicted=unit_step(predicted_output)
        print(predicted)
        error = output[i] - predicted
        print ("error",error)
        if output[i] == predicted:
            count = count+1
            dw1 = 0
            dw2 = 0

        else:
            dw1 = a*error*inputs[i][0]
            dw2 = a*error*inputs[i][1]
        w[0] = w[0]+dw1
        w[1] = w[1]+dw2
        print("w0(updated)",w[0],"w1(updated)",w[1])
    if count == 4:
        break
    else:
        count = 0
